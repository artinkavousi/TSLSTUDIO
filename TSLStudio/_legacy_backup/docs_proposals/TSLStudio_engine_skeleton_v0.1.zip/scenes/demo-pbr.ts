// Minimal demo scene wiring; integrate into your routes manually.
import { Scene, PerspectiveCamera, Mesh, BoxGeometry } from 'three';
import { createRenderer } from '../engine/core/renderer';
import { createInspector } from '../engine/core/inspector';
import { createPBRStandard } from '../engine/materials/pbrStandard';

export function bootDemoPBR(container: HTMLElement) {
  const canvas = document.createElement('canvas');
  container.appendChild(canvas);
  const { renderer, resize } = createRenderer({ canvas });
  const scene = new Scene();
  const camera = new PerspectiveCamera(60, 1, 0.1, 100);
  camera.position.set(2.5, 1.5, 3.5);

  const geo = new BoxGeometry(1, 1, 1);
  const { material } = createPBRStandard({ metalness: 0.2, roughness: 0.4 });
  const mesh = new Mesh(geo, material);
  scene.add(mesh);

  const insp = createInspector();

  function onResize() {
    const w = container.clientWidth || window.innerWidth;
    const h = container.clientHeight || window.innerHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    resize(w, h);
  }
  window.addEventListener('resize', onResize);
  onResize();

  let last = performance.now();
  function loop() {
    const now = performance.now();
    const dt = (now - last) / 1000;
    last = now;
    mesh.rotation.y += dt * 0.6;
    renderer.render(scene, camera);
    insp.update();
    requestAnimationFrame(loop);
  }
  loop();

  return { dispose() { window.removeEventListener('resize', onResize); container.removeChild(canvas); } };
}
