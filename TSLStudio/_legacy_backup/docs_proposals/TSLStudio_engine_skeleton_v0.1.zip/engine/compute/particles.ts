// Compute particles placeholder; keep API shape stable for later GPU buffers.
export type ParticlesOpts = { count: number; integrator?: 'euler' | 'verlet' };
export function createParticles(opts: ParticlesOpts) {
  const { count, integrator = 'euler' } = opts;
  // Stub buffers
  const positions = new Float32Array(count * 3);
  const velocities = new Float32Array(count * 3);

  function step(dt: number) {
    // CPU fallback stub for now
    for (let i = 0; i < count; i++) {
      const idx = i * 3;
      positions[idx] += velocities[idx] * dt;
      positions[idx + 1] += velocities[idx + 1] * dt;
      positions[idx + 2] += velocities[idx + 2] * dt;
    }
  }

  return { buffers: { positions, velocities }, step, integrator };
}
