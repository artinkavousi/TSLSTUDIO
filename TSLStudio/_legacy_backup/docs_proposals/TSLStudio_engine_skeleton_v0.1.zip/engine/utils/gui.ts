// Optional Tweakpane bindings (no dependency here to avoid forcing it).
export function bindGUI<T extends Record<string, any>>(_: T) {
  // NO-OP: integrate with your existing UI later
  return;
}
