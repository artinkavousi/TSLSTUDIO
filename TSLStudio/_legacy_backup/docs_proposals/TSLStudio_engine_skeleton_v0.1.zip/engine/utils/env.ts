// Environment helpers placeholder; plug PMREM/HDRI when needed.
export type EnvOpts = { exposure?: number };
export function applyEnv(opts: EnvOpts = {}) {
  // Hook for future HDRI/LUT setup
  return { exposure: opts.exposure ?? 1.0 };
}
