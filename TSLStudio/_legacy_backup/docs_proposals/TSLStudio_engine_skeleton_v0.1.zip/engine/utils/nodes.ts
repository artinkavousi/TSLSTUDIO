// Common math helpers (TSL-agnostic for now).
export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
export const saturate = (v: number) => clamp(v, 0, 1);
export const remap = (v: number, a: number, b: number, c: number, d: number) => c + (v - a) * (d - c) / (b - a);
