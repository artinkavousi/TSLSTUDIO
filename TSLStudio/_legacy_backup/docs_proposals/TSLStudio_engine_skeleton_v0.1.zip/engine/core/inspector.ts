// Minimal overlay for FPS/time (opt-in to keep base untouched).
export function createInspector() {
  let last = performance.now();
  let frames = 0;
  let fps = 0;
  const el = document.createElement('div');
  el.style.cssText = 'position:fixed;top:8px;left:8px;background:#0008;color:#fff;padding:6px 8px;font:12px/1.2 monospace;border-radius:8px;z-index:9999';
  el.textContent = 'fps: 0';
  document.body.appendChild(el);

  function update() {
    const now = performance.now();
    frames++;
    if (now - last > 1000) {
      fps = Math.round((frames * 1000) / (now - last));
      frames = 0;
      last = now;
      el.textContent = `fps: ${fps}`;
    }
  }

  return { update, el };
}
