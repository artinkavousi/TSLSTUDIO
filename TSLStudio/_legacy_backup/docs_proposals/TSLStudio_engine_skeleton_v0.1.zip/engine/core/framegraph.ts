// Ultra-thin pass orchestration; keep logic minimal.
export type PassContext = {
  time: number;
  dt: number;
  frame: number;
};

export type Pass = {
  name: string;
  exec: (ctx: PassContext) => void;
};

export function createFramegraph() {
  const passes: Pass[] = [];
  function add(pass: Pass) { passes.push(pass); return api; }
  function clear() { passes.length = 0; }
  function run(ctx: PassContext) { for (const p of passes) p.exec(ctx); }

  const api = { add, clear, run, passes };
  return api;
}
