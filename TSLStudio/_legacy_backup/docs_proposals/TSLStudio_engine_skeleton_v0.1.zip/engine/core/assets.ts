// Simple asset cache; expand later with KTX2/EXR loaders
const cache = new Map<string, unknown>();

export async function load<T>(key: string, loader: () => Promise<T>): Promise<T> {
  if (cache.has(key)) return cache.get(key) as T;
  const res = await loader();
  cache.set(key, res);
  return res;
}

export function get<T>(key: string): T | undefined {
  return cache.get(key) as T | undefined;
}
