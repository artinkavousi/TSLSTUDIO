// Minimal WebGPU renderer bootstrap (non-breaking, additive).
import { WebGPURenderer, Scene, PerspectiveCamera, ColorManagement, SRGBColorSpace, ACESFilmicToneMapping } from 'three/webgpu';
import { Color } from 'three';

export type RendererOpts = {
  canvas?: HTMLCanvasElement;
  antialias?: boolean;
  toneMappingExposure?: number;
  dpr?: number;
};

export function createRenderer(opts: RendererOpts = {}) {
  const { canvas, antialias = true, toneMappingExposure = 1.0, dpr = Math.min(2, window.devicePixelRatio || 1) } = opts;
  const renderer = new WebGPURenderer({ canvas, antialias });
  // Color / tone
  ColorManagement.enabled = true;
  renderer.toneMapping = ACESFilmicToneMapping;
  renderer.toneMappingExposure = toneMappingExposure;
  renderer.outputColorSpace = SRGBColorSpace;
  renderer.setPixelRatio(dpr);

  function resize(w: number = window.innerWidth, h: number = window.innerHeight) {
    renderer.setSize(w, h, false);
  }

  return { renderer, resize };
}
