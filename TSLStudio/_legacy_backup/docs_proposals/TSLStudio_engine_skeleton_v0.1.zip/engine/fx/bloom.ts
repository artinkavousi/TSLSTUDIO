// Simple bloom stub: return a pass interface that can be inserted into framegraph.
export type BloomOpts = { threshold?: number; intensity?: number; radius?: number };
export function createBloom(opts: BloomOpts = {}) {
  const { threshold = 1.0, intensity = 0.8, radius = 0.6 } = opts;
  const pass = {
    name: 'bloom',
    exec() {
      // TODO: hook into NodePass/TSL once wired; keep stub non-invasive.
    }
  };
  return { pass, params: { threshold, intensity, radius } };
}
