// Baseline Node/TSL PBR material placeholder (non-breaking stub).
import { MeshPhysicalNodeMaterial } from 'three/webgpu';
import type { Node } from 'three/nodes';

export type PBRStandardOpts = {
  color?: Node;
  metalness?: number | Node;
  roughness?: number | Node;
  normal?: Node;
  ior?: number;
  transmission?: number | Node;
  clearcoat?: number | Node;
  sheen?: number | Node;
  anisotropy?: { strength: number, direction?: Node };
};

export function createPBRStandard(opts: PBRStandardOpts = {}) {
  const mat = new MeshPhysicalNodeMaterial();
  // NOTE: keep assignments guarded; expand later per TSL nodes availability.
  if (typeof opts.metalness === 'number') mat.metalness = opts.metalness;
  if (typeof opts.roughness === 'number') mat.roughness = opts.roughness;
  if (typeof opts.ior === 'number') mat.ior = opts.ior;
  if (typeof opts.transmission === 'number') (mat as any).transmission = opts.transmission;
  return { material: mat };
}
