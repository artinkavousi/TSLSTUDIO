# TSLStudio Engine Skeleton (v0.1)

This is a **non-breaking** additive skeleton to drop into your existing `TSLStudio/` root.
It assumes Three r180± with WebGPU enabled. Files are stubs; fill in TSL nodes later.

- Keep your current pipeline; these modules are optional utilities.
- Start by wiring `scenes/demo-pbr.ts` into a scratch route or page.
