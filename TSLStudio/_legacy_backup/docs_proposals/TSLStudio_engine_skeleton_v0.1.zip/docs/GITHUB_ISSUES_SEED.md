# GitHub Issues Seed — TSLStudio Engine v0

Copy/paste these into GitHub as issues (or use `gh issue create` per section).

## M0 — Repo Hygiene
- [ ] Add `/engine/*` folder without touching existing pipeline
- [ ] Add ESLint/Prettier + tsconfig paths `@engine/*`
- [ ] Pin Three to r180±; confirm WebGPU builds

## M1 — Core Bootstrap
- [ ] `renderer.ts` with tone mapping + resize
- [ ] `framegraph.ts` pass runner
- [ ] `assets.ts` cache
- [ ] `inspector.ts` overlay

## M2 — Material Foundation
- [ ] `pbrStandard.ts` NodeMaterial baseline + slots
- [ ] Triplanar/matcap utility nodes (follow TSL conventions)
- [ ] Clearcoat/Sheen/Aniso helpers

## M3 — Post‑FX Stack
- [ ] Bloom, Vignette, Filmgrain, Chromab
- [ ] Color Grading (3D LUT)
- [ ] TAA, DOF

## M4 — Compute
- [ ] Particles buffers + step
- [ ] Curl noise field
- [ ] SDF ops + raymarch mat
- [ ] (flagged) 2D fluid toy

## M5 — R3F Wrappers (thin)
- [ ] <PBRStandard />, <Bloom />, <ColorGrading />, <Particles />

## M6 — Agent API & Schemas
- [ ] material.schema.json, fxchain.schema.json, compute.schema.json
- [ ] applyConfig(scene, json)

## M7 — Docs & Demos
- [ ] Demo scenes and docs pages

## M8 — QA & CI
- [ ] GPU feature detect + fallback notice
- [ ] Perf toggles
- [ ] Visual regression screenshots
